package viceCity.core.interfaces;

public class ControllerImpl implements Controller{

    @Override
    public String addPlayer(String name) {
        return null;
    }

    @Override
    public String addGun(String type, String name) {
        return null;
    }

    @Override
    public String addGunToPlayer(String name) {
        return null;
    }

    @Override
    public String fight() {
        return null;
    }
}
