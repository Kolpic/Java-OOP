package christmasPastryShop.entities.delicacies.interfaces;

public interface Delicacy {
    String getName();

    double getPortion();

    double getPrice();
}
