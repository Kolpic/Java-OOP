package catHouse.entities.toys;

public class Mouse extends BaseToy{

    private final static int SOFTNESS = 5;
    private final static double PRICE = 15;

    public Mouse() {
        super(SOFTNESS, PRICE);
    }
}
