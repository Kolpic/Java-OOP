package football.entities.supplement;

public abstract class BaseSupplement implements Supplement{

    private int energy;
    private double price;

    public BaseSupplement(int energy, double price) {
        this.energy = energy;
        this.price = price;
    }

}
